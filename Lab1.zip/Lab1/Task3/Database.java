class Database{
public static void main (String[] args){
String name="Hamza";
int age = 18;
String grade = "A+";
float Cgpa = 3.9f;
String gender = "M";
String foreigner = "No";
int Studentid = 0034;

System.out.println(name);
System.out.println(age);
System.out.println(grade);
System.out.println(Cgpa);
System.out.println(gender);
System.out.println(foreigner);
System.out.println(Studentid);
}
}