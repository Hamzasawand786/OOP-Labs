class pattern{
public static void main (String[] args){
 System.out.println("*********");
 System.out.println("*\t*");
 System.out.println("*\t*");
 System.out.println("*\t*");
 System.out.println("*\t*");
 System.out.println("*********");

}
}